package at.fhtw.swkom.paperless.repos;

import at.fhtw.swkom.paperless.domain.DocumentsSavedview;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DocumentsSavedviewRepository extends JpaRepository<DocumentsSavedview, Integer> {
}
