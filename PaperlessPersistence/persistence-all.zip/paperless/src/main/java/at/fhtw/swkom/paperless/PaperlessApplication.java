package at.fhtw.swkom.paperless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PaperlessApplication {

    public static void main(final String[] args) {
        SpringApplication.run(PaperlessApplication.class, args);
    }

}
