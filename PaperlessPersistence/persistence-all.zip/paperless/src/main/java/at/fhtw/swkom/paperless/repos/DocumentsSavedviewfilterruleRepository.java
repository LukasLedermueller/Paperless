package at.fhtw.swkom.paperless.repos;

import at.fhtw.swkom.paperless.domain.DocumentsSavedviewfilterrule;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DocumentsSavedviewfilterruleRepository extends JpaRepository<DocumentsSavedviewfilterrule, Integer> {
}
