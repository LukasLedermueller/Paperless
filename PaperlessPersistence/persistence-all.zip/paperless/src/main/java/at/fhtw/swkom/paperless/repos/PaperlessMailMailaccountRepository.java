package at.fhtw.swkom.paperless.repos;

import at.fhtw.swkom.paperless.domain.PaperlessMailMailaccount;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PaperlessMailMailaccountRepository extends JpaRepository<PaperlessMailMailaccount, Integer> {
}
